﻿
namespace müzikuygulama
{
    partial class kullaniciCalmaListesi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(kullaniciCalmaListesi));
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.sarkiIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sarkiAdiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tarihDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sanatciIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.albumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.turDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sureDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dinlenmeSayisiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sarkıURLDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.prolab3DataSet13 = new müzikuygulama.prolab3DataSet13();
            this.table_SarkiTableAdapter6 = new müzikuygulama.prolab3DataSet13TableAdapters.Table_SarkiTableAdapter();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.table_SarkiListeTableAdapter1 = new müzikuygulama.prolab3DataSet1TableAdapters.Table_SarkiListeTableAdapter();
            this.tableKullaniciBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.prolab3DataSet18 = new müzikuygulama.prolab3DataSet18();
            this.tableKullaniciBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.prolab3DataSet17 = new müzikuygulama.prolab3DataSet17();
            this.label9 = new System.Windows.Forms.Label();
            this.prolab3DataSet15 = new müzikuygulama.prolab3DataSet15();
            this.tableKullaniciBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.table_KullaniciTableAdapter = new müzikuygulama.prolab3DataSet15TableAdapters.Table_KullaniciTableAdapter();
            this.prolab3DataSet16 = new müzikuygulama.prolab3DataSet16();
            this.tableKullaniciBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.table_KullaniciTableAdapter1 = new müzikuygulama.prolab3DataSet16TableAdapters.Table_KullaniciTableAdapter();
            this.label10 = new System.Windows.Forms.Label();
            this.table_KullaniciTableAdapter2 = new müzikuygulama.prolab3DataSet17TableAdapters.Table_KullaniciTableAdapter();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.table_KullaniciTableAdapter3 = new müzikuygulama.prolab3DataSet18TableAdapters.Table_KullaniciTableAdapter();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.listBox7 = new System.Windows.Forms.ListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.listBox8 = new System.Windows.Forms.ListBox();
            this.button8 = new System.Windows.Forms.Button();
            this.axWindowsMediaPlayer1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolab3DataSet13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableKullaniciBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolab3DataSet18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableKullaniciBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolab3DataSet17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolab3DataSet15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableKullaniciBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolab3DataSet16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableKullaniciBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label2.Font = new System.Drawing.Font("Jokerman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(454, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(451, 35);
            this.label2.TabIndex = 0;
            this.label2.Text = "ÇALMA LİSTENİZE HOŞGELDİNİZ";
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox9.Controls.Add(this.button4);
            this.groupBox9.Controls.Add(this.button7);
            this.groupBox9.Controls.Add(this.button6);
            this.groupBox9.Font = new System.Drawing.Font("Arial Black", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox9.Location = new System.Drawing.Point(619, 89);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(198, 290);
            this.groupBox9.TabIndex = 4;
            this.groupBox9.TabStop = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button4.Font = new System.Drawing.Font("Arial Black", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.Location = new System.Drawing.Point(18, 119);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(161, 68);
            this.button4.TabIndex = 15;
            this.button4.Text = "LİSTELE";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button7.Font = new System.Drawing.Font("Arial Black", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button7.Location = new System.Drawing.Point(18, 203);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(161, 64);
            this.button7.TabIndex = 24;
            this.button7.Text = "ARKADAŞ EKLE";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button6.Font = new System.Drawing.Font("Arial Black", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button6.Location = new System.Drawing.Point(18, 32);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(161, 68);
            this.button6.TabIndex = 16;
            this.button6.Text = "ŞARKI EKLE";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox10.Controls.Add(this.dataGridView7);
            this.groupBox10.Font = new System.Drawing.Font("Arial Black", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox10.Location = new System.Drawing.Point(12, 385);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(1186, 203);
            this.groupBox10.TabIndex = 5;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "ŞARKILAR";
            this.groupBox10.Enter += new System.EventHandler(this.groupBox10_Enter);
            // 
            // dataGridView7
            // 
            this.dataGridView7.AutoGenerateColumns = false;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sarkiIDDataGridViewTextBoxColumn,
            this.sarkiAdiDataGridViewTextBoxColumn,
            this.tarihDataGridViewTextBoxColumn,
            this.sanatciIDDataGridViewTextBoxColumn,
            this.albumDataGridViewTextBoxColumn,
            this.turDataGridViewTextBoxColumn,
            this.sureDataGridViewTextBoxColumn,
            this.dinlenmeSayisiDataGridViewTextBoxColumn,
            this.sarkıURLDataGridViewTextBoxColumn});
            this.dataGridView7.DataSource = this.bindingSource1;
            this.dataGridView7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView7.Location = new System.Drawing.Point(3, 32);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.RowHeadersWidth = 51;
            this.dataGridView7.RowTemplate.Height = 24;
            this.dataGridView7.Size = new System.Drawing.Size(1180, 168);
            this.dataGridView7.TabIndex = 0;
            this.dataGridView7.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView7_CellContentClick);
            this.dataGridView7.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView7_MouseDoubleClick);
            // 
            // sarkiIDDataGridViewTextBoxColumn
            // 
            this.sarkiIDDataGridViewTextBoxColumn.DataPropertyName = "SarkiID";
            this.sarkiIDDataGridViewTextBoxColumn.HeaderText = "SarkiID";
            this.sarkiIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sarkiIDDataGridViewTextBoxColumn.Name = "sarkiIDDataGridViewTextBoxColumn";
            this.sarkiIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.sarkiIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // sarkiAdiDataGridViewTextBoxColumn
            // 
            this.sarkiAdiDataGridViewTextBoxColumn.DataPropertyName = "SarkiAdi";
            this.sarkiAdiDataGridViewTextBoxColumn.HeaderText = "SarkiAdi";
            this.sarkiAdiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sarkiAdiDataGridViewTextBoxColumn.Name = "sarkiAdiDataGridViewTextBoxColumn";
            this.sarkiAdiDataGridViewTextBoxColumn.Width = 125;
            // 
            // tarihDataGridViewTextBoxColumn
            // 
            this.tarihDataGridViewTextBoxColumn.DataPropertyName = "Tarih";
            this.tarihDataGridViewTextBoxColumn.HeaderText = "Tarih";
            this.tarihDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tarihDataGridViewTextBoxColumn.Name = "tarihDataGridViewTextBoxColumn";
            this.tarihDataGridViewTextBoxColumn.Width = 125;
            // 
            // sanatciIDDataGridViewTextBoxColumn
            // 
            this.sanatciIDDataGridViewTextBoxColumn.DataPropertyName = "SanatciID";
            this.sanatciIDDataGridViewTextBoxColumn.HeaderText = "SanatciID";
            this.sanatciIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sanatciIDDataGridViewTextBoxColumn.Name = "sanatciIDDataGridViewTextBoxColumn";
            this.sanatciIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // albumDataGridViewTextBoxColumn
            // 
            this.albumDataGridViewTextBoxColumn.DataPropertyName = "Album";
            this.albumDataGridViewTextBoxColumn.HeaderText = "Album";
            this.albumDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.albumDataGridViewTextBoxColumn.Name = "albumDataGridViewTextBoxColumn";
            this.albumDataGridViewTextBoxColumn.Width = 125;
            // 
            // turDataGridViewTextBoxColumn
            // 
            this.turDataGridViewTextBoxColumn.DataPropertyName = "Tur";
            this.turDataGridViewTextBoxColumn.HeaderText = "Tur";
            this.turDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.turDataGridViewTextBoxColumn.Name = "turDataGridViewTextBoxColumn";
            this.turDataGridViewTextBoxColumn.Width = 125;
            // 
            // sureDataGridViewTextBoxColumn
            // 
            this.sureDataGridViewTextBoxColumn.DataPropertyName = "Sure";
            this.sureDataGridViewTextBoxColumn.HeaderText = "Sure";
            this.sureDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sureDataGridViewTextBoxColumn.Name = "sureDataGridViewTextBoxColumn";
            this.sureDataGridViewTextBoxColumn.Width = 125;
            // 
            // dinlenmeSayisiDataGridViewTextBoxColumn
            // 
            this.dinlenmeSayisiDataGridViewTextBoxColumn.DataPropertyName = "DinlenmeSayisi";
            this.dinlenmeSayisiDataGridViewTextBoxColumn.HeaderText = "DinlenmeSayisi";
            this.dinlenmeSayisiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dinlenmeSayisiDataGridViewTextBoxColumn.Name = "dinlenmeSayisiDataGridViewTextBoxColumn";
            this.dinlenmeSayisiDataGridViewTextBoxColumn.Width = 125;
            // 
            // sarkıURLDataGridViewTextBoxColumn
            // 
            this.sarkıURLDataGridViewTextBoxColumn.DataPropertyName = "SarkıURL";
            this.sarkıURLDataGridViewTextBoxColumn.HeaderText = "SarkıURL";
            this.sarkıURLDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sarkıURLDataGridViewTextBoxColumn.Name = "sarkıURLDataGridViewTextBoxColumn";
            this.sarkıURLDataGridViewTextBoxColumn.Width = 125;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataMember = "Table_Sarki";
            this.bindingSource1.DataSource = this.prolab3DataSet13;
            // 
            // prolab3DataSet13
            // 
            this.prolab3DataSet13.DataSetName = "prolab3DataSet13";
            this.prolab3DataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // table_SarkiTableAdapter6
            // 
            this.table_SarkiTableAdapter6.ClearBeforeFill = true;
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.listBox1.Font = new System.Drawing.Font("Arial Black", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 28;
            this.listBox1.Location = new System.Drawing.Point(-2, 89);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(202, 284);
            this.listBox1.TabIndex = 6;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            this.listBox1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox1_MouseDoubleClick);
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.listBox2.Font = new System.Drawing.Font("Arial Black", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 28;
            this.listBox2.Location = new System.Drawing.Point(206, 89);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(206, 284);
            this.listBox2.TabIndex = 7;
            this.listBox2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox2_MouseDoubleClick);
            // 
            // listBox3
            // 
            this.listBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.listBox3.Font = new System.Drawing.Font("Arial Black", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 28;
            this.listBox3.Location = new System.Drawing.Point(418, 89);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(195, 284);
            this.listBox3.TabIndex = 8;
            this.listBox3.SelectedIndexChanged += new System.EventHandler(this.listBox3_SelectedIndexChanged);
            this.listBox3.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox3_MouseDoubleClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Jokerman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(73, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 29);
            this.label3.TabIndex = 9;
            this.label3.Text = "POP";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Jokerman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(269, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 29);
            this.label4.TabIndex = 10;
            this.label4.Text = "JAZZ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Jokerman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(468, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 29);
            this.label5.TabIndex = 11;
            this.label5.Text = "KLASİK";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label6.Font = new System.Drawing.Font("Jokerman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(9, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(143, 35);
            this.label6.TabIndex = 12;
            this.label6.Text = "Hoşgeldin";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label7.Font = new System.Drawing.Font("Jokerman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(142, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 35);
            this.label7.TabIndex = 13;
            this.label7.Text = "label7";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Jokerman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(645, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(153, 29);
            this.label8.TabIndex = 19;
            this.label8.Text = "İŞLEMLERİM";
            // 
            // table_SarkiListeTableAdapter1
            // 
            this.table_SarkiListeTableAdapter1.ClearBeforeFill = true;
            // 
            // tableKullaniciBindingSource3
            // 
            this.tableKullaniciBindingSource3.DataMember = "Table_Kullanici";
            this.tableKullaniciBindingSource3.DataSource = this.prolab3DataSet18;
            // 
            // prolab3DataSet18
            // 
            this.prolab3DataSet18.DataSetName = "prolab3DataSet18";
            this.prolab3DataSet18.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableKullaniciBindingSource2
            // 
            this.tableKullaniciBindingSource2.DataMember = "Table_Kullanici";
            this.tableKullaniciBindingSource2.DataSource = this.prolab3DataSet17;
            // 
            // prolab3DataSet17
            // 
            this.prolab3DataSet17.DataSetName = "prolab3DataSet17";
            this.prolab3DataSet17.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Jokerman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(831, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(298, 29);
            this.label9.TabIndex = 21;
            this.label9.Text = "PREMİUM KULLANICILAR";
            // 
            // prolab3DataSet15
            // 
            this.prolab3DataSet15.DataSetName = "prolab3DataSet15";
            this.prolab3DataSet15.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableKullaniciBindingSource
            // 
            this.tableKullaniciBindingSource.DataMember = "Table_Kullanici";
            this.tableKullaniciBindingSource.DataSource = this.prolab3DataSet15;
            // 
            // table_KullaniciTableAdapter
            // 
            this.table_KullaniciTableAdapter.ClearBeforeFill = true;
            // 
            // prolab3DataSet16
            // 
            this.prolab3DataSet16.DataSetName = "prolab3DataSet16";
            this.prolab3DataSet16.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableKullaniciBindingSource1
            // 
            this.tableKullaniciBindingSource1.DataMember = "Table_Kullanici";
            this.tableKullaniciBindingSource1.DataSource = this.prolab3DataSet16;
            // 
            // table_KullaniciTableAdapter1
            // 
            this.table_KullaniciTableAdapter1.ClearBeforeFill = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Jokerman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(1158, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(198, 29);
            this.label10.TabIndex = 23;
            this.label10.Text = "ARKADAŞLARIM";
            // 
            // table_KullaniciTableAdapter2
            // 
            this.table_KullaniciTableAdapter2.ClearBeforeFill = true;
            // 
            // listBox4
            // 
            this.listBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.listBox4.Font = new System.Drawing.Font("Arial Black", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBox4.FormattingEnabled = true;
            this.listBox4.ItemHeight = 28;
            this.listBox4.Location = new System.Drawing.Point(1135, 89);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(251, 284);
            this.listBox4.TabIndex = 25;
            this.listBox4.SelectedIndexChanged += new System.EventHandler(this.listBox4_SelectedIndexChanged);
            this.listBox4.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox4_MouseDoubleClick);
            // 
            // table_KullaniciTableAdapter3
            // 
            this.table_KullaniciTableAdapter3.ClearBeforeFill = true;
            // 
            // listBox5
            // 
            this.listBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.listBox5.Font = new System.Drawing.Font("Arial Black", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBox5.FormattingEnabled = true;
            this.listBox5.ItemHeight = 26;
            this.listBox5.Location = new System.Drawing.Point(-2, 654);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(198, 186);
            this.listBox5.TabIndex = 26;
            this.listBox5.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox5_MouseDoubleClick);
            // 
            // listBox6
            // 
            this.listBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.listBox6.Font = new System.Drawing.Font("Arial Black", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBox6.FormattingEnabled = true;
            this.listBox6.ItemHeight = 26;
            this.listBox6.Location = new System.Drawing.Point(202, 654);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(196, 186);
            this.listBox6.TabIndex = 27;
            this.listBox6.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox6_MouseDoubleClick);
            // 
            // listBox7
            // 
            this.listBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.listBox7.Font = new System.Drawing.Font("Arial Black", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBox7.FormattingEnabled = true;
            this.listBox7.ItemHeight = 26;
            this.listBox7.Location = new System.Drawing.Point(404, 654);
            this.listBox7.Name = "listBox7";
            this.listBox7.Size = new System.Drawing.Size(195, 186);
            this.listBox7.TabIndex = 28;
            this.listBox7.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox7_MouseDoubleClick);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Jokerman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(61, 626);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 25);
            this.label11.TabIndex = 29;
            this.label11.Text = "POP";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Jokerman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(468, 627);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(83, 25);
            this.label12.TabIndex = 30;
            this.label12.Text = "KLASİK";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Jokerman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(269, 626);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 25);
            this.label13.TabIndex = 31;
            this.label13.Text = "JAZZ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label14.Font = new System.Drawing.Font("Jokerman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(102, 591);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(188, 35);
            this.label14.TabIndex = 32;
            this.label14.Text = " Çalma Listesi";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label15.Font = new System.Drawing.Font("Jokerman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(6, 591);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(104, 35);
            this.label15.TabIndex = 33;
            this.label15.Text = "label15";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // listBox8
            // 
            this.listBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.listBox8.Font = new System.Drawing.Font("Arial Black", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBox8.FormattingEnabled = true;
            this.listBox8.ItemHeight = 26;
            this.listBox8.Location = new System.Drawing.Point(823, 89);
            this.listBox8.Name = "listBox8";
            this.listBox8.Size = new System.Drawing.Size(306, 290);
            this.listBox8.TabIndex = 34;
            this.listBox8.SelectedIndexChanged += new System.EventHandler(this.listBox8_SelectedIndexChanged);
            this.listBox8.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox8_MouseDoubleClick);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button8.Font = new System.Drawing.Font("Arial Black", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button8.Location = new System.Drawing.Point(1049, 711);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(273, 40);
            this.button8.TabIndex = 37;
            this.button8.Text = "Yenile";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // axWindowsMediaPlayer1
            // 
            this.axWindowsMediaPlayer1.Enabled = true;
            this.axWindowsMediaPlayer1.Location = new System.Drawing.Point(1049, 626);
            this.axWindowsMediaPlayer1.Name = "axWindowsMediaPlayer1";
            this.axWindowsMediaPlayer1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer1.OcxState")));
            this.axWindowsMediaPlayer1.Size = new System.Drawing.Size(273, 46);
            this.axWindowsMediaPlayer1.TabIndex = 38;
            this.axWindowsMediaPlayer1.Enter += new System.EventHandler(this.axWindowsMediaPlayer1_Enter);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button9.Font = new System.Drawing.Font("Arial Black", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button9.Location = new System.Drawing.Point(679, 627);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(292, 46);
            this.button9.TabIndex = 39;
            this.button9.Text = "Pop Çalma Listesini Ekle";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button10.Font = new System.Drawing.Font("Arial Black", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button10.Location = new System.Drawing.Point(679, 677);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(292, 46);
            this.button10.TabIndex = 40;
            this.button10.Text = "Jazz Çalma Listesini Ekle";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button11.Font = new System.Drawing.Font("Arial Black", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button11.Location = new System.Drawing.Point(679, 729);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(292, 46);
            this.button11.TabIndex = 41;
            this.button11.Text = "Klasik Çalma Listesini Ekle";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // kullaniciCalmaListesi
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1389, 787);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.axWindowsMediaPlayer1);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.listBox8);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.listBox7);
            this.Controls.Add(this.listBox6);
            this.Controls.Add(this.listBox5);
            this.Controls.Add(this.listBox4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.listBox3);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.label2);
            this.Name = "kullaniciCalmaListesi";
            this.Load += new System.EventHandler(this.kullaniciCalmaListesi_Load_1);
            this.groupBox9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolab3DataSet13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableKullaniciBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolab3DataSet18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableKullaniciBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolab3DataSet17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolab3DataSet15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableKullaniciBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prolab3DataSet16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableKullaniciBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private prolab3DataSet7 prolab3DataSet7;
        private System.Windows.Forms.BindingSource tableSarkiBindingSource;
        private prolab3DataSet7TableAdapters.Table_SarkiTableAdapter table_SarkiTableAdapter;
        private prolab3DataSet8 prolab3DataSet8;
        private System.Windows.Forms.BindingSource tableSarkiBindingSource1;
        private prolab3DataSet8TableAdapters.Table_SarkiTableAdapter table_SarkiTableAdapter1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private prolab3DataSet9 prolab3DataSet9;
        private System.Windows.Forms.BindingSource tableSarkiBindingSource2;
        private prolab3DataSet9TableAdapters.Table_SarkiTableAdapter table_SarkiTableAdapter2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox5;
        private prolab3DataSet10 prolab3DataSet10;
        private System.Windows.Forms.BindingSource tableSarkiBindingSource3;
        private prolab3DataSet10TableAdapters.Table_SarkiTableAdapter table_SarkiTableAdapter3;
        private prolab3DataSet11 prolab3DataSet11;
        private System.Windows.Forms.BindingSource tableSarkiBindingSource4;
        private prolab3DataSet11TableAdapters.Table_SarkiTableAdapter table_SarkiTableAdapter4;
        private prolab3DataSet12 prolab3DataSet12;
        private System.Windows.Forms.BindingSource tableSarkiBindingSource5;
        private prolab3DataSet12TableAdapters.Table_SarkiTableAdapter table_SarkiTableAdapter5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.DataGridView dataGridView7;
        private prolab3DataSet13 prolab3DataSet13;
        private System.Windows.Forms.BindingSource bindingSource1;
        private prolab3DataSet13TableAdapters.Table_SarkiTableAdapter table_SarkiTableAdapter6;
        private System.Windows.Forms.DataGridViewTextBoxColumn sarkiIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sarkiAdiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tarihDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sanatciIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn albumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn turDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sureDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dinlenmeSayisiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sarkıURLDataGridViewTextBoxColumn;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private prolab3DataSet1TableAdapters.Table_SarkiListeTableAdapter table_SarkiListeTableAdapter1;
        private System.Windows.Forms.Label label9;
        private prolab3DataSet15 prolab3DataSet15;
        private System.Windows.Forms.BindingSource tableKullaniciBindingSource;
        private prolab3DataSet15TableAdapters.Table_KullaniciTableAdapter table_KullaniciTableAdapter;
        private prolab3DataSet16 prolab3DataSet16;
        private System.Windows.Forms.BindingSource tableKullaniciBindingSource1;
        private prolab3DataSet16TableAdapters.Table_KullaniciTableAdapter table_KullaniciTableAdapter1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button7;
        private prolab3DataSet17 prolab3DataSet17;
        private System.Windows.Forms.BindingSource tableKullaniciBindingSource2;
        private prolab3DataSet17TableAdapters.Table_KullaniciTableAdapter table_KullaniciTableAdapter2;
        private System.Windows.Forms.ListBox listBox4;
        private prolab3DataSet18 prolab3DataSet18;
        private System.Windows.Forms.BindingSource tableKullaniciBindingSource3;
        private prolab3DataSet18TableAdapters.Table_KullaniciTableAdapter table_KullaniciTableAdapter3;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.ListBox listBox6;
        private System.Windows.Forms.ListBox listBox7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ListBox listBox8;
        private System.Windows.Forms.Button button8;
        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
    }
}